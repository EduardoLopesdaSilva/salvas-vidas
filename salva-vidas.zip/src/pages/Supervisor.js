import { useEffect, useState } from "react";

export function Supervisor() {

    const [postos, setPostos] = useState([]);
    const [historico, setHistorico] = useState([]);

    useEffect(() => {

        // carregar postos
        const dadosPostos = localStorage.getItem("postos");
        if (dadosPostos) {
            setPostos(JSON.parse(dadosPostos));
        }

        // carregar histórico
        const dadosHistorico = localStorage.getItem("historico_turnos");
        if (dadosHistorico) {
            setHistorico(JSON.parse(dadosHistorico));
        }

    }, []);
    //Criar metricas
    const [metricas, setMetricas] = useState({
        totalTurnos: 0,
        totalPrevencoes: 0,
        totalLesoes: 0,
        postosOcupados: 0
    });
    if (dadosPostos && dadosHistorico) {

        const postosArray = JSON.parse(dadosPostos);
        const historicoArray = JSON.parse(dadosHistorico);

        const totalTurnos = historicoArray.length;

        const totalPrevencoes = historicoArray.reduce(
            (total, t) => total + t.prevencoes, 0
        );

        const totalLesoes = historicoArray.reduce(
            (total, t) => total + t.lesoes.length, 0
        );

        const postosOcupados = postosArray.filter(
            p => p.status === "OCUPADO"
        ).length;

        setMetricas({
            totalTurnos,
            totalPrevencoes,
            totalLesoes,
            postosOcupados
        });
    }

    //Pegar data de hoje
    const hoje = new Date().toLocaleDateString("pt-BR");

    return (
        <div>
            <h2>Métricas do Sistema</h2>

        <p>Total de Turnos: {metricas.totalTurnos}</p>
        <p>Total de Prevenções: {metricas.totalPrevencoes}</p>
        <p>Total de Lesões: {metricas.totalLesoes}</p>
        <p>Postos Ocupados Agora: {metricas.postosOcupados}</p>

        <hr />

            <h1>Painel do Supervisor</h1>

            <hr />

            <h2>Postos em Tempo Real</h2>

            {postos.map(p => (
                <div key={p.id}>
                    <strong>{p.nome}</strong> - {p.status}

                    {p.salvaVida && (
                        <span> ( {p.salvaVida} )</span>
                    )}
                </div>
            ))}

            <hr />

            <h2>Histórico de Turnos</h2>

            {historico.length === 0 && <p>Nenhum registro ainda</p>}

            {historico.map((h, i) => (
                <div key={i}>
                    <p><strong>{h.usuario}</strong> - Posto {h.posto}</p>
                    <p>Início: {h.inicio}</p>
                    <p>Fim: {h.fim}</p>
                    <p>Prevenções: {h.prevencoes}</p>
                    <hr />
                </div>
            ))}
        </div>
    );
}